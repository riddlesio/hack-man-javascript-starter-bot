A basic JavaScript starter bot written for The AI Games' Warlight 2 challenge
